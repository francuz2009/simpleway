<template>
  <div class="quote">
    <div class="container">
      <div class="quote__icon"  data-aos="fade-in" data-aos-delay="300">Немного великих цитат</div>
      <p class="quote__text"  data-aos="fade-in" data-aos-delay="400">«Не волнуйся, если не работает. Если бы все всегда работало, у тебя бы не было работы.»</p>
    </div>
  </div>
</template>

