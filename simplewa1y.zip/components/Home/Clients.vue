<template>
  <div class="cl" id="clients">
    <div class="shape__top">
      <svg data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 120" preserveAspectRatio="none">
        <path d="M1200 120L0 16.48 0 0 1200 0 1200 120z" class="clients__fiil-top" />
      </svg>
    </div>
    <div class="container ">
      <div class="clients">
        <div class="section__header">
          <h2 class="section__title w" data-aos="fade-up" data-aos-delay="300">
            Кто наши клиенты:
          </h2>
          <h3 class="section__suptitle w" data-aos="fade-up" data-aos-delay="400">
            Нашими клиентами за частую является малый и средний бизнес, так как это<br>
            амбициозные люди которые понимают что они хотят это и зачем им это нужно.
          </h3>
        </div>
      </div>
    </div>
  </div>
</template>
