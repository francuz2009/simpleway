<template>
  <div id="about" class="sec__about">
    <div class="container">
      <div class="section__header">
        <h2 class="section__title" data-aos="fade-up" data-aos-delay="400">
          О нас
        </h2>
      </div>
      <div class="about">
        <div class="about__item  about__item--border" data-aos="fade-up" data-aos-delay="500">
          <img class="about__img" src="@/assets/images/home/about_cat.png" alt="" data-aos="fade-up" data-aos-delay="300">
          <div class="about__content" >
            <h3 class="about__title" data-aos="fade-up" data-aos-delay="300">
              ЧТО ОБЫЧНО ПИШУТ КОМПАНИИ
            </h3>
            <p class="about__text" data-aos="fade-up" data-aos-delay="400">
              Мы команда Simple Way. Работаем на рынке Краснодарского края и России. Разрабатываем уникальные продукты, лендинги, блоги, интернет-магазины, порталы. Помимо создания сайтов в перечень наших услуг входит графический дизайн, SEO оптимизация, контекстная и таргетированная реклама, информационное сопровож-дение организаций и видеонаблюдением.
            </p>
            <img class="about__img-arr" src="@/assets/images/arrows/strelka.png" alt="" data-aos="fade-up" data-aos-delay="500">
            <div class="about__content">
              <p class="about__textp" data-aos="fade-up" data-aos-delay="500">
                Этот текст должен заставить вас поверить, что мы профессионалы
              </p>
            </div>
          </div>
        </div>
        <div class="about__item">
          <img class="about__img" src="@/assets/images/home/about_dv.png" alt="" data-aos="fade-up" data-aos-delay="600">
          <div class="about__content">
            <h3 class="about__title" data-aos="fade-up" data-aos-delay="700">
              КТО МЫ НА САМОМ ДЕЛЕ
            </h3>
            <p class="about__text" data-aos="fade-up" data-aos-delay="800">
              Мы команда энтузиастов объеденённых одними целями и интересами. Мы умеем создавать не плохие проекты и «раскручивать» их. Так же не плохо получается дизайн и не стандартное продвижение, администрирование организаций и монтаж видеонаблюдения. В общем мастера на все руки.
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
