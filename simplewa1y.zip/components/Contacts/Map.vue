<template>
  <div class="map">
    <iframe frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?q=%D0%9A%D1%80%D0%B0%D1%81%D0%BD%D0%BE%D0%B4%D0%B0%D1%80&amp;t=m&amp;z=12&amp;output=embed&amp;iwloc=near" title="%3$s" aria-label="%3$s"></iframe>
  </div>
</template>
