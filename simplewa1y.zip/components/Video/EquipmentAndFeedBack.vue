<template>
	<div>
		<div class="green">
			<div class="divider">
			<svg data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 120" preserveAspectRatio="none">
					<path d="M1200 0L0 0 598.97 114.72 1200 0z" class="shape-fill3"></path>
			</svg>
			</div>
			<div class="container">
				<h2 class ="stages__title white" data-aos="fade-in" data-aos-delay="300">Оборудование и ПО</h2>
				<p class="it__text white" data-aos="fade-left" data-aos-delay="400">Стоимость монтажа видеонаблюдения во многом зависит от того, какое оборудование будет использоваться. Обычно необходимы: </p>
				<p class="it__text white" data-aos="fade-left" data-aos-delay="400">1. <strong> Камеры.</strong> Может быть установлена одна видеокамера или сразу несколько. Их различают по типу сигнала, месторасположению и предназначению. Используют цифровые, аналоговые, IP-устройства. Основная задача камеры – трансляция изображения на монитор. Современные IP камеры не только подают изображение в неизмененном виде сразу на экран, но и обладают функцией кодирования и сжатия информации для удобства хранения и обеспечения секретности. Их чаще используют при установке систем видеонаблюдения. Бюджетный вариант – цифровые/аналоговые камеры, которые идеальны для установки видеонаблюдения в офисе или квартире. </p><br>
				<p class="it__text white" data-aos="fade-right" data-aos-delay="500">2. <strong>Провода, кабели. </strong> Монтаж систем видеонаблюдения обязательно включает прокладку проводов, которые позволяют получить достаточное качество изображения с наружной камеры наблюдения. Используется три вида кабелей – коаксиальный, комбинированный, витая пара. Работы по монтажу видеонаблюдения проводятся только после подбора кабелей с учётом того, будут ли они прокладываться внутри здания или на улице.</p><br>
				<p class="it__text white" data-aos="fade-left" data-aos-delay="600">3. <strong>Программное обеспечение.</strong> После завершения монтажа камер видеонаблюдения и прокладки проводов производится настройка системы. ПО позволяет программировать камеры на включение/отключение датчиками звука или движения, по расписанию, получить удаленный доступ к различным объектам. Кроме того, программное обеспечение необходимо для регулировки параметров работы камеры, создания видеоархива, обработки информации. Работы по монтажу систем видеонаблюдения должны обязательно учитывать возможность установки сразу нескольких камер, совместимость с модемом или локальной сетью, использования разных интерфейсов.</p><br>
				<p class="it__text white" data-aos="fade-right" data-aos-delay="700">Установка видеонаблюдения под ключ в Краснодаре обязательно включает в себя также подбор системы подачи энергии (основной и дополнительный блоки бесперебойного питания, резервный аккумулятор), ресивера, телевизора или монитора, при необходимости – внешнего жесткого диска.</p><br>
			</div>
			<div class="divider-bottom">
				<svg data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 120" preserveAspectRatio="none">
					<path d="M598.97 114.72L0 0 0 120 1200 120 1200 0 598.97 114.72z" class="shape-fill4"></path>
				</svg>
			</div>
		</div>
<div class="call__back blue">
		<div class="container">
			<div class="call__back__inner">
				<div class="call__back__prev">
					<div class="stage__text stand cb" data-aos="fade-in" data-aos-delay="300"> Если Вы не знаете какой сайт нужен,то напишите. Перезвоним</div>
					<img class="call__back__icon" src="@/assets/images/arrows/strelka-4.png" alt="" data-aos="fade-in" data-aos-delay="400">
					<img class="call__back-img dali" src="@/assets/images/video/dali.png" alt="" data-aos="fade-in" data-aos-delay="450">
				</div>
				<div class="call__back__form">
					<form class="modal__callback">
						<input type="hidden" name="project_name" value="Site Name">
						<input type="hidden" name="admin_email" value="lifeforfun2010@yandex.ru">
						<input type="hidden" name="form_subject" value="Form Subject">
						<!-- END Hidden Required Fields -->
					
						<input type="text" name="Name" class="feedback-form__input" placeholder="Ваше имя" required data-aos="fade-in" data-aos-delay="500"><br>
						<input type="text" name="Phone" class="feedback-form__input" placeholder="Введите ваш телефон." required data-aos="fade-in" data-aos-delay="550"><br>
						<textarea name="Message" id="" сlass="feedback-form__input" placeholder ="Ваше сообщение" data-aos="fade-in" data-aos-delay="600"></textarea>	
						<div class="checkbox"> 
							<input type="checkbox" class="checkbox__input" disabled checked data-aos="fade-in" data-aos-delay="600">
							<label for="formAgreement" class="chekbox__label" data-aos="fade-in" data-aos-delay="600">Нажимая кнопку «Отправить», вы даете согласие на обработку своих персональных данных.</label>
						</div>
						
						<button class="contact-form__btn page__btn" data-aos="fade-in" data-aos-delay="650">Отправить</button>
					</form>
				</div>
			</div>
		</div>	
	</div>
	<div class = "light-blue">
		<div class="shape-divider3">
			<svg data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 120" preserveAspectRatio="none">
        <path d="M1200 120L0 16.48 0 0 1200 0 1200 120z" class="shape-fill5"></path>
			</svg>
		</div>
		
			<div class="quote light-blue">
				<div class="container">
					<div class="quote__icon black" data-aos="fade-in" data-aos-delay="300">Немного великих цитат</div>
					<p class="quote__text qblack" data-aos="fade-in" data-aos-delay="400"> «xxx: Искренне верил в непорочность людей!</p>
					<p class="quote__text qblack" data-aos="fade-in" data-aos-delay="500">xxx: А потом мы поставили видеонаблюдение…» </p>
				</div>

		</div>		
	</div>		
	</div>
</template>

<script>
export default {
  props:{
    data:{},
  },
}
</script>

