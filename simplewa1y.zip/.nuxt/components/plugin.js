import Vue from 'vue'
import { wrapFunctional } from './utils'

const components = {
  Footer: () => import('../..\\components\\Footer.vue' /* webpackChunkName: "components/footer" */).then(c => wrapFunctional(c.default || c)),
  HeaderMain: () => import('../..\\components\\HeaderMain.vue' /* webpackChunkName: "components/header-main" */).then(c => wrapFunctional(c.default || c)),
  HeaderPage: () => import('../..\\components\\HeaderPage.vue' /* webpackChunkName: "components/header-page" */).then(c => wrapFunctional(c.default || c)),
  Navigation: () => import('../..\\components\\Navigation.vue' /* webpackChunkName: "components/navigation" */).then(c => wrapFunctional(c.default || c)),
  ContactsContactIntro: () => import('../..\\components\\Contacts\\ContactIntro.vue' /* webpackChunkName: "components/contacts-contact-intro" */).then(c => wrapFunctional(c.default || c)),
  ContactsMap: () => import('../..\\components\\Contacts\\Map.vue' /* webpackChunkName: "components/contacts-map" */).then(c => wrapFunctional(c.default || c)),
  HomeAbout: () => import('../..\\components\\Home\\About.vue' /* webpackChunkName: "components/home-about" */).then(c => wrapFunctional(c.default || c)),
  HomeClients: () => import('../..\\components\\Home\\Clients.vue' /* webpackChunkName: "components/home-clients" */).then(c => wrapFunctional(c.default || c)),
  HomeClientsIf: () => import('../..\\components\\Home\\ClientsIf.vue' /* webpackChunkName: "components/home-clients-if" */).then(c => wrapFunctional(c.default || c)),
  HomeMainIntro: () => import('../..\\components\\Home\\MainIntro.vue' /* webpackChunkName: "components/home-main-intro" */).then(c => wrapFunctional(c.default || c)),
  HomePopup: () => import('../..\\components\\Home\\Popup.vue' /* webpackChunkName: "components/home-popup" */).then(c => wrapFunctional(c.default || c)),
  HomePortfolio: () => import('../..\\components\\Home\\Portfolio.vue' /* webpackChunkName: "components/home-portfolio" */).then(c => wrapFunctional(c.default || c)),
  HomeServices: () => import('../..\\components\\Home\\Services.vue' /* webpackChunkName: "components/home-services" */).then(c => wrapFunctional(c.default || c)),
  ItIntro: () => import('../..\\components\\It\\ItIntro.vue' /* webpackChunkName: "components/it-intro" */).then(c => wrapFunctional(c.default || c)),
  ItQuote: () => import('../..\\components\\It\\ItQuote.vue' /* webpackChunkName: "components/it-quote" */).then(c => wrapFunctional(c.default || c)),
  ItStage: () => import('../..\\components\\It\\Stage.vue' /* webpackChunkName: "components/it-stage" */).then(c => wrapFunctional(c.default || c)),
  NavigationIcon: () => import('../..\\components\\Navigation\\icon.vue' /* webpackChunkName: "components/navigation-icon" */).then(c => wrapFunctional(c.default || c)),
  NavigationSidebar: () => import('../..\\components\\Navigation\\Sidebar.vue' /* webpackChunkName: "components/navigation-sidebar" */).then(c => wrapFunctional(c.default || c)),
  SiteAreasWork: () => import('../..\\components\\site\\AreasWork.vue' /* webpackChunkName: "components/site-areas-work" */).then(c => wrapFunctional(c.default || c)),
  SiteIntroSite: () => import('../..\\components\\site\\IntroSite.vue' /* webpackChunkName: "components/site-intro-site" */).then(c => wrapFunctional(c.default || c)),
  SiteForm: () => import('../..\\components\\site\\SiteForm.vue' /* webpackChunkName: "components/site-form" */).then(c => wrapFunctional(c.default || c)),
  SiteStageSite: () => import('../..\\components\\site\\StageSite.vue' /* webpackChunkName: "components/site-stage-site" */).then(c => wrapFunctional(c.default || c)),
  VideoChooseUs: () => import('../..\\components\\Video\\ChooseUs.vue' /* webpackChunkName: "components/video-choose-us" */).then(c => wrapFunctional(c.default || c)),
  VideoEquipmentAndFeedBack: () => import('../..\\components\\Video\\EquipmentAndFeedBack.vue' /* webpackChunkName: "components/video-equipment-and-feed-back" */).then(c => wrapFunctional(c.default || c)),
  VideoBenefits: () => import('../..\\components\\Video\\VideoBenefits.vue' /* webpackChunkName: "components/video-benefits" */).then(c => wrapFunctional(c.default || c)),
  VideoIntro: () => import('../..\\components\\Video\\VideoIntro.vue' /* webpackChunkName: "components/video-intro" */).then(c => wrapFunctional(c.default || c)),
  VideoStage: () => import('../..\\components\\Video\\VideoStage.vue' /* webpackChunkName: "components/video-stage" */).then(c => wrapFunctional(c.default || c))
}

for (const name in components) {
  Vue.component(name, components[name])
  Vue.component('Lazy' + name, components[name])
}
