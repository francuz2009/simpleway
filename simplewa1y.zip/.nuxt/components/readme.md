# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<Footer>` | `<footer>` (components/Footer.vue)
- `<HeaderMain>` | `<header-main>` (components/HeaderMain.vue)
- `<HeaderPage>` | `<header-page>` (components/HeaderPage.vue)
- `<Navigation>` | `<navigation>` (components/Navigation.vue)
- `<ContactsContactIntro>` | `<contacts-contact-intro>` (components/Contacts/ContactIntro.vue)
- `<ContactsMap>` | `<contacts-map>` (components/Contacts/Map.vue)
- `<HomeAbout>` | `<home-about>` (components/Home/About.vue)
- `<HomeClients>` | `<home-clients>` (components/Home/Clients.vue)
- `<HomeClientsIf>` | `<home-clients-if>` (components/Home/ClientsIf.vue)
- `<HomeMainIntro>` | `<home-main-intro>` (components/Home/MainIntro.vue)
- `<HomePopup>` | `<home-popup>` (components/Home/Popup.vue)
- `<HomePortfolio>` | `<home-portfolio>` (components/Home/Portfolio.vue)
- `<HomeServices>` | `<home-services>` (components/Home/Services.vue)
- `<ItIntro>` | `<it-intro>` (components/It/ItIntro.vue)
- `<ItQuote>` | `<it-quote>` (components/It/ItQuote.vue)
- `<ItStage>` | `<it-stage>` (components/It/Stage.vue)
- `<NavigationIcon>` | `<navigation-icon>` (components/Navigation/icon.vue)
- `<NavigationSidebar>` | `<navigation-sidebar>` (components/Navigation/Sidebar.vue)
- `<SiteAreasWork>` | `<site-areas-work>` (components/site/AreasWork.vue)
- `<SiteIntroSite>` | `<site-intro-site>` (components/site/IntroSite.vue)
- `<SiteForm>` | `<site-form>` (components/site/SiteForm.vue)
- `<SiteStageSite>` | `<site-stage-site>` (components/site/StageSite.vue)
- `<VideoChooseUs>` | `<video-choose-us>` (components/Video/ChooseUs.vue)
- `<VideoEquipmentAndFeedBack>` | `<video-equipment-and-feed-back>` (components/Video/EquipmentAndFeedBack.vue)
- `<VideoBenefits>` | `<video-benefits>` (components/Video/VideoBenefits.vue)
- `<VideoIntro>` | `<video-intro>` (components/Video/VideoIntro.vue)
- `<VideoStage>` | `<video-stage>` (components/Video/VideoStage.vue)
