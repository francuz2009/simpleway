import { wrapFunctional } from './utils'

export { default as Footer } from '../..\\components\\Footer.vue'
export { default as HeaderMain } from '../..\\components\\HeaderMain.vue'
export { default as HeaderPage } from '../..\\components\\HeaderPage.vue'
export { default as Navigation } from '../..\\components\\Navigation.vue'
export { default as ContactsContactIntro } from '../..\\components\\Contacts\\ContactIntro.vue'
export { default as ContactsMap } from '../..\\components\\Contacts\\Map.vue'
export { default as HomeAbout } from '../..\\components\\Home\\About.vue'
export { default as HomeClients } from '../..\\components\\Home\\Clients.vue'
export { default as HomeClientsIf } from '../..\\components\\Home\\ClientsIf.vue'
export { default as HomeMainIntro } from '../..\\components\\Home\\MainIntro.vue'
export { default as HomePopup } from '../..\\components\\Home\\Popup.vue'
export { default as HomePortfolio } from '../..\\components\\Home\\Portfolio.vue'
export { default as HomeServices } from '../..\\components\\Home\\Services.vue'
export { default as ItIntro } from '../..\\components\\It\\ItIntro.vue'
export { default as ItQuote } from '../..\\components\\It\\ItQuote.vue'
export { default as ItStage } from '../..\\components\\It\\Stage.vue'
export { default as NavigationIcon } from '../..\\components\\Navigation\\icon.vue'
export { default as NavigationSidebar } from '../..\\components\\Navigation\\Sidebar.vue'
export { default as SiteAreasWork } from '../..\\components\\site\\AreasWork.vue'
export { default as SiteIntroSite } from '../..\\components\\site\\IntroSite.vue'
export { default as SiteForm } from '../..\\components\\site\\SiteForm.vue'
export { default as SiteStageSite } from '../..\\components\\site\\StageSite.vue'
export { default as VideoChooseUs } from '../..\\components\\Video\\ChooseUs.vue'
export { default as VideoEquipmentAndFeedBack } from '../..\\components\\Video\\EquipmentAndFeedBack.vue'
export { default as VideoBenefits } from '../..\\components\\Video\\VideoBenefits.vue'
export { default as VideoIntro } from '../..\\components\\Video\\VideoIntro.vue'
export { default as VideoStage } from '../..\\components\\Video\\VideoStage.vue'

export const LazyFooter = import('../..\\components\\Footer.vue' /* webpackChunkName: "components/footer" */).then(c => wrapFunctional(c.default || c))
export const LazyHeaderMain = import('../..\\components\\HeaderMain.vue' /* webpackChunkName: "components/header-main" */).then(c => wrapFunctional(c.default || c))
export const LazyHeaderPage = import('../..\\components\\HeaderPage.vue' /* webpackChunkName: "components/header-page" */).then(c => wrapFunctional(c.default || c))
export const LazyNavigation = import('../..\\components\\Navigation.vue' /* webpackChunkName: "components/navigation" */).then(c => wrapFunctional(c.default || c))
export const LazyContactsContactIntro = import('../..\\components\\Contacts\\ContactIntro.vue' /* webpackChunkName: "components/contacts-contact-intro" */).then(c => wrapFunctional(c.default || c))
export const LazyContactsMap = import('../..\\components\\Contacts\\Map.vue' /* webpackChunkName: "components/contacts-map" */).then(c => wrapFunctional(c.default || c))
export const LazyHomeAbout = import('../..\\components\\Home\\About.vue' /* webpackChunkName: "components/home-about" */).then(c => wrapFunctional(c.default || c))
export const LazyHomeClients = import('../..\\components\\Home\\Clients.vue' /* webpackChunkName: "components/home-clients" */).then(c => wrapFunctional(c.default || c))
export const LazyHomeClientsIf = import('../..\\components\\Home\\ClientsIf.vue' /* webpackChunkName: "components/home-clients-if" */).then(c => wrapFunctional(c.default || c))
export const LazyHomeMainIntro = import('../..\\components\\Home\\MainIntro.vue' /* webpackChunkName: "components/home-main-intro" */).then(c => wrapFunctional(c.default || c))
export const LazyHomePopup = import('../..\\components\\Home\\Popup.vue' /* webpackChunkName: "components/home-popup" */).then(c => wrapFunctional(c.default || c))
export const LazyHomePortfolio = import('../..\\components\\Home\\Portfolio.vue' /* webpackChunkName: "components/home-portfolio" */).then(c => wrapFunctional(c.default || c))
export const LazyHomeServices = import('../..\\components\\Home\\Services.vue' /* webpackChunkName: "components/home-services" */).then(c => wrapFunctional(c.default || c))
export const LazyItIntro = import('../..\\components\\It\\ItIntro.vue' /* webpackChunkName: "components/it-intro" */).then(c => wrapFunctional(c.default || c))
export const LazyItQuote = import('../..\\components\\It\\ItQuote.vue' /* webpackChunkName: "components/it-quote" */).then(c => wrapFunctional(c.default || c))
export const LazyItStage = import('../..\\components\\It\\Stage.vue' /* webpackChunkName: "components/it-stage" */).then(c => wrapFunctional(c.default || c))
export const LazyNavigationIcon = import('../..\\components\\Navigation\\icon.vue' /* webpackChunkName: "components/navigation-icon" */).then(c => wrapFunctional(c.default || c))
export const LazyNavigationSidebar = import('../..\\components\\Navigation\\Sidebar.vue' /* webpackChunkName: "components/navigation-sidebar" */).then(c => wrapFunctional(c.default || c))
export const LazySiteAreasWork = import('../..\\components\\site\\AreasWork.vue' /* webpackChunkName: "components/site-areas-work" */).then(c => wrapFunctional(c.default || c))
export const LazySiteIntroSite = import('../..\\components\\site\\IntroSite.vue' /* webpackChunkName: "components/site-intro-site" */).then(c => wrapFunctional(c.default || c))
export const LazySiteForm = import('../..\\components\\site\\SiteForm.vue' /* webpackChunkName: "components/site-form" */).then(c => wrapFunctional(c.default || c))
export const LazySiteStageSite = import('../..\\components\\site\\StageSite.vue' /* webpackChunkName: "components/site-stage-site" */).then(c => wrapFunctional(c.default || c))
export const LazyVideoChooseUs = import('../..\\components\\Video\\ChooseUs.vue' /* webpackChunkName: "components/video-choose-us" */).then(c => wrapFunctional(c.default || c))
export const LazyVideoEquipmentAndFeedBack = import('../..\\components\\Video\\EquipmentAndFeedBack.vue' /* webpackChunkName: "components/video-equipment-and-feed-back" */).then(c => wrapFunctional(c.default || c))
export const LazyVideoBenefits = import('../..\\components\\Video\\VideoBenefits.vue' /* webpackChunkName: "components/video-benefits" */).then(c => wrapFunctional(c.default || c))
export const LazyVideoIntro = import('../..\\components\\Video\\VideoIntro.vue' /* webpackChunkName: "components/video-intro" */).then(c => wrapFunctional(c.default || c))
export const LazyVideoStage = import('../..\\components\\Video\\VideoStage.vue' /* webpackChunkName: "components/video-stage" */).then(c => wrapFunctional(c.default || c))
