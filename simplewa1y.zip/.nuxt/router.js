import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _b4e1a82a = () => interopDefault(import('..\\pages\\contacts\\index.vue' /* webpackChunkName: "pages/contacts/index" */))
const _4ceedca3 = () => interopDefault(import('..\\pages\\cozdanie-sajta\\index.vue' /* webpackChunkName: "pages/cozdanie-sajta/index" */))
const _9135555a = () => interopDefault(import('..\\pages\\informatsionnoe-soprovozhdenie\\index.vue' /* webpackChunkName: "pages/informatsionnoe-soprovozhdenie/index" */))
const _73502de9 = () => interopDefault(import('..\\pages\\videonablyudenie\\index.vue' /* webpackChunkName: "pages/videonablyudenie/index" */))
const _1cd4ba9e = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/contacts",
    component: _b4e1a82a,
    name: "contacts"
  }, {
    path: "/cozdanie-sajta",
    component: _4ceedca3,
    name: "cozdanie-sajta"
  }, {
    path: "/informatsionnoe-soprovozhdenie",
    component: _9135555a,
    name: "informatsionnoe-soprovozhdenie"
  }, {
    path: "/videonablyudenie",
    component: _73502de9,
    name: "videonablyudenie"
  }, {
    path: "/",
    component: _1cd4ba9e,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
